# Q01c

# Initialise variables
amount = 113
num_twenties == amount // 20
left_over = amount % 20

# Display results
print("There are "+ str(num_twenties) + " £20s in £113")
print("There is £"  str(left over) + " left over")
