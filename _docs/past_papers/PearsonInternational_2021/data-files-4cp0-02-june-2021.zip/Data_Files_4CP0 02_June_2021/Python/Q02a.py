# Q02a

# Initialise variables

# Print prompts, take and check input from user



