# Q04(a)

import random

# Get input




# Generate a random number between 10 and 30 inclusive




# Generate the product code - first three letters of product name and the random number




# Display the product code and the product name



