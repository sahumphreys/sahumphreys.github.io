import java.util.Scanner;

public class Q02a {

	public static void main(String[] args) {
		
		// Initialise variables 

    	// Print prompts, take and check input from user 



	} // End of main program
} // End of class