public class Q01c {

	public static void main(String[] args) {

		// Initialise variables 
		int amount = 113;
		int num_twenties == amount / 20;
		int left_over = amount % 20;
		
		// Display results 
		System.out.println("There are "+ Integer.toString(num_twenties) +" £20s in £113");
		System.out.println("There are "+ Integer.toString(leftover) ," left over");
	} // End of main program
} // End of class