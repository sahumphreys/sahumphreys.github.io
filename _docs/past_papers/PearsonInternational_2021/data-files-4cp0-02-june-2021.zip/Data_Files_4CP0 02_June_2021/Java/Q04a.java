import java.util.Scanner;
import java.util.Random;

public class Q04a {

	public static void main(String[] args) {
			
		// Get input 


		
		// Generate a random number between 10 and 30 inclusive



    	// Generate the product code - first three letters of product name and the random number



		// Display the product code and the product name


	} // End of main program
} // End of class