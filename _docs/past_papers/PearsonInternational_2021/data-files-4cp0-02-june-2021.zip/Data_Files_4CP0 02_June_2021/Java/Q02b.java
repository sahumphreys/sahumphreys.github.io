import java.util.Scanner;

public class Q02b {

	public static void main(String[] args) {
	
		int booksSold = 0;
		int profit = 0;
		
		System.out.print("Enter the number of books sold ");
		Scanner input = new Scanner(System.in);
		booksSold = Integer.parseInt(input.nextLine());	
		System.out.print("Enter the profit ");
		profit = Integer.parseInt(input.nextLine());	
		
      // Add your code 
      if
      {
         System.out.print("Poor performance this week")
      }
      else if
      {
         System.out.print("Sales and profit are excellent this week")
      }
      else if
      {
         System.out.print("Sales and profit are good this week")
      }
      else
      {

      } // End of If...else if....else statement
	}// End of main program
} // End of class