﻿using System;
namespace Q02a
{
    class Program
    {
        static void Main(string[] args)
        {
          // Initialise variables

          // Print prompts, take and check user input


        } // End of main program
    } // End of class
} // End of namespace