﻿using System;
namespace Q04a
{
    class Program
    {
        static void Main(string[] args)
        {  
            // Get input


            
            // Generate a random number between 10 and 30 inclusive


            
            // Generate the product code - first three letters of product name and the random number



            // Display the product code and the product name



        }  // End of main program
    }  // End of class
}  // End of namespace