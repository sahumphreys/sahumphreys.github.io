﻿using System;
namespace Q02b
{
    class Program
    {
        static void Main(string[] args)
        {
            int booksSold = 0;
            int profit = 0;

            Console.Write("Enter the number of books sold: ");
            booksSold = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the profit: ");
            profit = Convert.ToInt32(Console.ReadLine());

            // Add your code
            if
            {
                Console.WriteLine("Poor performance this week");
            }
            else if
            {
                Console.WriteLine("Sales and profit are excellent this week");
            }
            else if
            {
                Console.WriteLine("Sales and profit are good this week");
            }
            else
            {
               
            }

        } // End of main program
    }  // End of class
}  // End of namespace