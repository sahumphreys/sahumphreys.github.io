﻿using System;
namespace Q01c
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialise variables and assign values
            int amount = 113;
            int num_twenties == amount / 20;
            int left_over = amount % 20;

            // Display results
            Console.WriteLine("There are " + num_twenties + " £20s in £113");
            Console.WriteLine("There is £" + leftover , " left over");
            Console.ReadKey();

        } // End of main program
    } // End of class
} // End of namespace