#Q04b

# Subprogram checkWord -------------------------------------------------
def checkWord(pWord):

    newWord = ""
    count = len(pWord) - 1

    while count >= 0:
        newWord = newWord + pWord[count]
        count = count - 1

    print("The original word is", pWord, "the new word is", newWord)
    
    if newWord == pWord:
        print("Yes it is")
    else:
        print("No it is not")
        
# End of subprogram checkWord ------------------------------------------

# Main program ---------------------------------------------------------
checkWord("random")
checkWord("repaper")


    
