# Q04a

denaryPlaceholders = [128, 64, 32, 16, 8, 4, 2, 1]
binaryPattern = ""
denaryNumber = 0
count = 0

# Add your code here

