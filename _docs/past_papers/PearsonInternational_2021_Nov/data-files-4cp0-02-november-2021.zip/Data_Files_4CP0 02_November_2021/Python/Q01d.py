# Q01d

number1 = int(input("Enter the first number "))
number2 = int(input("Enter the second number ")) 

if number1 = number2:
    print("Numbers are equal")
elif number1 > number2:
    print("The highest number is", number2, "and the lowest number is", number1)
eles: 
    print("The highest number is", number1, "and the lowest number is", number2)


    
