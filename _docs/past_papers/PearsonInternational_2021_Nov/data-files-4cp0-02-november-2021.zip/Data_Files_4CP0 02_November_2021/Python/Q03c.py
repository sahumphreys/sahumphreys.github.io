# Q03c

# Input requested
year = int(input("Enter a year in this format YYYY e.g. 2000: "))

# Process input and display the result
# Add your code here

    
