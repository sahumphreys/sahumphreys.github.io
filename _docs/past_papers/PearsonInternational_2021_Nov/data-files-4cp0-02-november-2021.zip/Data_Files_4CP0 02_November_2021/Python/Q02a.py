# Q02a

numberList = [5, 9, 13, 63, 65, 79, 86, 100]
start = 0
middle = 0
end = len(numberList) - 1
found = False
count = 0

# Add your code here








# Do not add your own code below this line
    
# Result of the search is displayed (this has been done for you)

if found == True:
    print(item, "was found in the list")
else:
    print(item, "is not in the list")
