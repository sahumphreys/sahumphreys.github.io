# Q03a

# Subprogram to get and validate the month number-----------------------------------------------------
def display():
    monthNumber = 0
    while monthNumber < 1 or monthNumber > 12:
        monthNumber = int(input("Enter the month number [1 to 12]: "))
    return monthNumber

# End of subprogram display --------------------------------------------------------------------------


# Subprogram to show the name of the month and the number of days in the month -----------------------
def showMonthNameAndDays(pMonth):

    # Month number, days in the month and month name
    monthAndDays = [
        [1, 31, "January"],
        [2, 28, "February"],
        [3, 31, "March"],
        [4, 30, "April"],
        [5, 31, "May"],
        [6, 30, "June"],
        [7, 31, "July"],
        [8, 31, "August"],
        [9, 30, "September"],
        [10, 31, "October"],
        [11, 30, "November"],
        [12, 31, "December"],]
    count = 0
    found = False

    while count < len(monthAndDays) and found == False:
        if monthAndDays[count][0] == pMonth:
               found = True
               print(monthAndDays[count][2], "has", monthAndDays[count][1], "days")
        count = count + 1
        
# End of subprogram showMonthNameAndDays ------------------------------------------------------------


# Main program ---------------------------------------------------------------------------------------
monthInput = display()
showMonthNameAndDays(monthInput)
