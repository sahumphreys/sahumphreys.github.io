# Q01e

# Print prompt and get number from user




# Create loop to display the table

