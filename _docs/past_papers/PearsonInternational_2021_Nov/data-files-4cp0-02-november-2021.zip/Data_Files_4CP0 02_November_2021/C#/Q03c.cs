﻿using System;

namespace Q03c
{
    class Program
    {
        static void Main(string[] args)
        {
            // Input requested 
            Console.WriteLine("Enter a year in this format YYYY e.g. 2000: ");
            int year = Convert.ToInt32(Console.ReadLine());

           // Process input and display the result
           // Add your code here
           













           
        } // End of main program
    } // End of class
} // End of namespace