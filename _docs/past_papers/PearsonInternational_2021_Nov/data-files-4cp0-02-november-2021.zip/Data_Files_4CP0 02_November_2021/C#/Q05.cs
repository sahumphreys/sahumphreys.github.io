using System;

namespace Q05
{
    class Program
    {
    static void Main(string[] args)
        {
            string[] wordArray = {"wind","leer","pushy","lade","size","sob","borrowing","list",
                                  "perish","hoax","sticks","seed","impel","large","male","silent",
                                  "quilt","sobbed","remarkable","fantastic","wire","reflective","putrid", 
                                  "pushover","swing"};

            // Add your code here
           





           
        } // End of main program
    }  // End of class program
} // End of namespace