﻿using System;

namespace Q04a
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] denaryPlaceholders = { 128, 64, 32, 16, 8, 4, 2, 1 };
            string binaryPattern = "";
            int denaryNumber = 0;
            int count = 0;

            // Add your code here
            














            
        } // End of main program
    } // End of class
} // End of namespace
