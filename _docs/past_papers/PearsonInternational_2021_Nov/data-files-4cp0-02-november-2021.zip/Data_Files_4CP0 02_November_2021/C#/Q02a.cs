﻿using System;

namespace Q02a
{
    class Q02a
    {
        static void Main(string[] args)
        {
            int[] numberList = { 5, 9, 13, 63, 65, 79, 86, 100 };
            int start = 0;
            int middle = 0;
            int end = numberList.Length - 1;
            bool found = false;
            int count = 0;

            // Add your code here

            








            

            // Do not add your own code below this line

            // Result of the search is displayed (this has been done for you)

            if (found == true)
            {
                Console.WriteLine(item + " was found in the list");
            }
            else
            {
                Console.WriteLine(item + "was not found in the list");
            }

            Console.ReadLine();
            
        } // End of main program
    } // End of class
} // End of namespace