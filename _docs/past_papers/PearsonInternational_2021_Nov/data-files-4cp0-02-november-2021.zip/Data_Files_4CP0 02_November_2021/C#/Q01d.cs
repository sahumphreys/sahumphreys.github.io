﻿using System;

namespace Q01d
{
    class Q01d
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first number");
            int number1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the second number");
            int number2 = Convert.ToInt32(Console.ReadLine());

            if (number1 = number2)
            {
                Console.WriteLine("The numbers are equal");
            } 
            else if (number1 > number2) 
            {
                Console.WriteLine("The highest number is " + number2 + " and the lowest number is " + number1);
            } 
            eles 
            {
                Console.WriteLine("The highest number is " + number1 + " and the lowest number is " + number2);
            }
            Console.ReadLine();
        } // End of main program
    } // End of class
} // End of namespace