﻿using System;

namespace Q04b
{
    class Program
    {
        // Subprogram checkWord -----------------------------------------------------------------------------
        static void checkWord(string pWord)
        {
            string newWord = "";
            int count = pWord.Length - 1;

            while (count >= 0)
            {
                newWord = newWord + pWord[count];
                count--;
            }

            Console.WriteLine("The original word is " + pWord + " the new word is " + newWord);

            if (newWord == pWord)
            {
                Console.WriteLine("Yes it is");
            }
            else
            {
                Console.WriteLine("No it is not");
            }
        }// End of subprogram checkWord ----------------------------------------------------------------------

        
        // Main program -------------------------------------------------------------------------------------
        static void Main(string[] args)
        {
            checkWord("random");
            checkWord("repaper");
            
        } // End of main program
    } // End of class
} // End of namespace