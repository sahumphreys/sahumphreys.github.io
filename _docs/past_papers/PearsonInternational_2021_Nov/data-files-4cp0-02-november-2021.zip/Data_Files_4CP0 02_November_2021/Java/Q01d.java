import java.util.Scanner;

public class Q01d {
    
    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the first number ");
        int number1 = Integer.parseInt(input.nextLine());
        
        System.out.print("Enter the second number ");
        int number2 = Integer.parseInt(input.nextLine());
        
        input.close();
        
        if (number1 = number2)
        {
            System.out.print("Numbers are equal");
        }
        else if (number1 > number2)
        {   
           System.out.print("The highest number is " + number2 + " and the lowest number is " +number1);
        }
        eles
        {
             System.out.print("The highest number is " + number1 + " and the lowest number is " +number2);
        }
    } // End of main program
} // End of class