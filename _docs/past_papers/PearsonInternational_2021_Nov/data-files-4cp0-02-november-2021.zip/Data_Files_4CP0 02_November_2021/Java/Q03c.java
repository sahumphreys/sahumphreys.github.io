import java.util.Scanner;

public class Q03c {
    
    public static void main(String[] args) {
       
        // Input requested
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a year in this format YYYY e.g. 2000 ");
    	int year = input.nextInt();
        input.close();
        
        // Process input and display the result
        // Add your code here
        















    } // End of main program
} // End of class