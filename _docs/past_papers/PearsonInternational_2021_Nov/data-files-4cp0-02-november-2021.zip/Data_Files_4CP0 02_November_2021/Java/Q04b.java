public class Q04b {
    
    // Subprogram checkWord ----------------------------------------------------------------------
    static void checkWord(String pWord)
    {
        String newWord = "";
        int count = pWord.length() - 1;
        
        while (count >=0)
        {
            newWord = newWord + pWord.charAt(count);
            count = count - 1;
        }
        
        System.out.println("The original word is " + pWord + " the new word is " + newWord);
        
        if (newWord.equals(pWord))
        {
            System.out.println("Yes it is");
        }
        else
        {
            System.out.println("No it is not");
        }
    } // End of subprogram checkWord ------------------------------------------------------------
  
    // Main program -----------------------------------------------------------------------------
    public static void main(String[] args) {
 
        checkWord("random");
        checkWord("repaper");
    } // End of main program
} // End of class