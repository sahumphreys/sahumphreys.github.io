import java.util.Scanner;

public class Q02a {

    public static void main(String[] args) {
      int[] numberList = { 5, 9, 13, 63, 65, 79, 86, 100 }; 
      int start = 0;
      int middle = 0;
      int end = numberList.length - 1;
      boolean found = false;
      int count = 0;
      
      // Add your code here
      









      
      
      // Do not add your own code below this line
      
      // Result of the search is displayed (this has been done for you)
      
      if (found == true)
      {
          System.out.print(item + " was found in the list");
      }
      else
      {
         System.out.print(item + " was not found in the list"); 
      }
    } // End of main program
} // End of class