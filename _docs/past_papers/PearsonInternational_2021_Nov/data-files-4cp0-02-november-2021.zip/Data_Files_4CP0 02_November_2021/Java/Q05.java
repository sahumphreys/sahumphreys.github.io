import java.util.Scanner;

public class Q05 {

    public static void main(String[] args)
    {
    
        String [] wordArray = {"wind","leer","pushy","lade","size","sob","borrowing","list",
                               "perish","hoax","sticks","seed","impel","large","male","silent",
                               "quilt","sobbed","remarkable","fantastic","wire","reflective","putrid", 
                            "pushover","swing"};

        // Add your code here
 





    } // End of Main program
} // End of class