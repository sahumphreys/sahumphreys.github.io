import java.util.Scanner;

public class Q01e {

    public static void main(String[] args) {
        
        // Print prompt and get number from user
        


        
        // Create loop to display the table
        




    } // End of main program  
} // End of class