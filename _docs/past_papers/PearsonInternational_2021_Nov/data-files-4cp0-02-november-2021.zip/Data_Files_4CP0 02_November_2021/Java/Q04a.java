import java.util.Scanner;

public class Q04a {

    public static void main(String[] args) {
        int[] denaryPlaceholders = { 128, 64, 32, 16, 8, 4, 2, 1 };
        String binaryPattern = "";
        int denaryNumber = 0;
        int count = 0;
        
        // Add your code here
        















    } // End of main program   
} // End of class