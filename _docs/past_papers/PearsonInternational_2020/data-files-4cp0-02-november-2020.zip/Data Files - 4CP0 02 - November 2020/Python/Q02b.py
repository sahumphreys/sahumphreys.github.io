#	Q02b

#	Set initial values of variables



# 	Request input



# 	Calculate number of panels needed



# 	Print out number of panels needed

