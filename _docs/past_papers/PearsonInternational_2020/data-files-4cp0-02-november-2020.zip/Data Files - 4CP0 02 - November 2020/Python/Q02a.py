#	Q2a

#	Initialise variables



#	Print prompt and take input from user



#	Calculate area and print out values



