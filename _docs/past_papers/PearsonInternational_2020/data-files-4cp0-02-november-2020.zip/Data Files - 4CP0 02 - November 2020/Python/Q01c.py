#	Q01c

numOne = 25
num Two = 36
numThree = numone * numTwo
display numThree
