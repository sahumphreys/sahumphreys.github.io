public class Q01c
{
    public static void main(String[] args)
    {
            int numOne = 25;
            int num Two = 36;
            int numThree = numone * numTwo;
            System.out.display(numThree);
    }
}
