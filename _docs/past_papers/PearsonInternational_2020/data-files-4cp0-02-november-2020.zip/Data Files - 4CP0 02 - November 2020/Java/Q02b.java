import java.util.Scanner;

public class q02b
{
    public static void main(String[] args)
    {
        // Set initial values of variables
	
	
		// Request input
	
	
		// Calculate number of panels
	
	
        // Print out number of panels needed
        
    }
}
