import java.util.Scanner;

public class q02a
{
    public static void main(String[] args)
    {
        // Initialise variables
        

		// Display prompt and take input from user
        

		// Calculate and print out values
        
    }
}
