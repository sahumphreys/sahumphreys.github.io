using System;

namespace Q02a_2020
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialise variables


            // Display prompt and take input from user


            // Calculate and print out values


            Console.ReadKey();
        }
    }
}
