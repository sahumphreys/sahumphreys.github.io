using System;

namespace Q02b_2020
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set initial values of variables


            // Request input


            // Calculate number of panels


            // Print out number of panels needed		


            Console.ReadKey();
        }
    }
}
