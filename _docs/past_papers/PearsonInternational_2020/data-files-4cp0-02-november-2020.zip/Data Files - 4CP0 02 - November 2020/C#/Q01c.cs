using System;

namespace Q01c_2020
{
    class Program
    {
        static void Main(string[] args)
        {
            int numOne = 25;
            int num Two = 36;
            int numThree = numone * numTwo;
            Console.display(numThree);
            Console.ReadKey();
        }
    }
}
