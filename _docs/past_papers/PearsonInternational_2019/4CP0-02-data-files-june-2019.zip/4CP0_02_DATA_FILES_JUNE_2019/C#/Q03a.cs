﻿using System;

namespace Q03a
{
    class Q03a
    {
        static void Main(string[] args)
        {

//	Open the input file



//	Open output file



//	Find errors and write to output file



//	Close files



        }
    }
}

