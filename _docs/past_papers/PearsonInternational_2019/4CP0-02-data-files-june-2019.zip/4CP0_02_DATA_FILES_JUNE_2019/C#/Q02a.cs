﻿using System;

namespace Q02a
{
    class Q02a
    {
        static void Main(string[] args)
        {
            //  Initialise variables

				
				
            //  Print prompt and take guess from user

				

            //  Create WHILE loop to check if guess is correct

				

            //  Report the correct answer to the user and indicate the number of guesses

			
			
        }
    }
}
