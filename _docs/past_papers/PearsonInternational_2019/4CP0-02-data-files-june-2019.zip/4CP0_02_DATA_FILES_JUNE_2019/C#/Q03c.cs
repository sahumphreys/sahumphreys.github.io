﻿using System;

namespace Q03c
{
    class Q03c
    {
        static void Main(string[] args)
        {
			// Enter your code here
        }
    }
}
