﻿using System;

namespace Q01c
{
    class Program
    {
        static void Main(string[] args)
        {
            int maxValue = 5
            int count = 0;
            while (count < maxValue)
                {
                    Console.WriteLine(count + "   " + Count + constantValue);
                    count = count + 1;
                }
            Console.ReadLine();
        }
    }
}