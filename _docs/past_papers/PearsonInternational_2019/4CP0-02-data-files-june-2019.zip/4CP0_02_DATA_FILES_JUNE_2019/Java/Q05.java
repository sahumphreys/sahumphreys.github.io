package 2019_Q5;

public class Main {

    public static void main(String[] args) 
    {
        String[][] libraryRecord =  {{"105MS" , "Marcus", "Smith", "25"},
                                     {"103AZ" , "Anthony" , "Zarrent" , "5" },
                                     {"108MW" , "Matt" , "White" , "12" },
                                     {"112DB" , "Denise" , "Bilton" , "58" },
                                     {"124MK" , "Malcolm" , "Kelly" , "26" },
                                     {"116UK" , "Uzere" , "Kevill" , "29" },
                                     {"127AL" , "Abduraheim" , "Leahy" , "94" },
                                     {"124LS" , "Laura" , "Sampras" , "50" },
                                     {"121AP" , "Azra" , "Potter" , "61" },
                                     {"115AC" , "Anthony" , "Calik" , "10" },
                                     {"117PI" , "Pablo" , "Iilyas" , "49" },
                                     {"113MM" , "Mark" , "Montgomerie" , "67" },
                                     {"130FH" , "Felicity" , "Heath" , "11" },
                                     {"132JA" , "Jill" , "Alexander" , "61" },
                                     {"123SG" , "Sara" , "Grimstow" , "9" },
                                     {"134KD" , "Kevin" , "Dawson" , "74" },
                                     {"122AB" , "Andrew" , "Bertwistle" , "42" },
                                     {"125JF" , "Jaide" , "Feehily" , "55" },
                                     {"128JS" , "Justin" , "Slater" , "68" },
                                     {"126CG" , "Colleen" , "Grohl" , "39" }};

// -------------------------------------------------------------------------------
// Write your code below this line
		
    }
}