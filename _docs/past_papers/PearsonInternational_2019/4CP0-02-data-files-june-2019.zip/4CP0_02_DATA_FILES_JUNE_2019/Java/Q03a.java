package q03a;

public class Q03a
{
    public static void main(String[] args) throws FileNotFoundException 
	// you may amend the throws FileNotFoundException if you wish
    {
	//	Open the input file
	


	//	Open the output file



	//	Find errors and write to output file
	
	
	
	//	Close files

	

	
    }
}
