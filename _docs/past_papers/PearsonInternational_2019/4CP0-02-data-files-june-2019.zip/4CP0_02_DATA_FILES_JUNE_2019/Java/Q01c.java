package Q01c;

public class Q01c
{
    public static void main(String[] args)
	{
        int count = 0;
        int maxValue = 5
        while (count < maxValue) 
        {
            System.out.println(count + "    " + Count + constantValue);
            count = count + 1;
        }
    }
}