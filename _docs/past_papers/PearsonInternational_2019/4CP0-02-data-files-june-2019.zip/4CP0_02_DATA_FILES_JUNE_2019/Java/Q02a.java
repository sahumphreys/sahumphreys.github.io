package Q02a

import java.util.Random;
import java.util.Scanner;

public class Q02a
{
	public static void main(String[] args)
	{
		//  Initialise variables



		//  Print prompt and take guess from user



		//  Create WHILE loop to check if guess is correct



		//  Report the correct answer to the user and indicate the number of guesses
		
	}
}