package q03c;

import java.util.Scanner;

public class Q03c
{
    public static void main(String[] args)
	{
        // Write your code here
    }
}
