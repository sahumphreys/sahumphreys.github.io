# Q03a

#	Open the file and input data


#	Open output file


#	Find errors and write to output file


#	Close files
