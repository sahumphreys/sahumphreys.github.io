# Q01c

count = 0

maxValue = 5

while (count < maxValue)
    print(count, Count + constantValue)
    count = count + 1
