# Q02a

from random import *

#  Initialise variables



#  Print prompt and take guess from user



#  Create WHILE loop to check if guess is correct



#  Report the correct answer to the user and indicate the number of guesses
